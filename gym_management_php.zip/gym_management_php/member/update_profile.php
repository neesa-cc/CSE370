<?php
require_once __DIR__ . "/../config/auth.php";
require_login(["member"]);
$title = "Update Profile";
$base = get_base_url();
$m_id = current_user_id();
$msg = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST["name"] ?? "");
    $address = trim($_POST["address"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $c_no = trim($_POST["c_no"] ?? "");
    $gender = trim($_POST["gender"] ?? "");
    $bmi = trim($_POST["bmi"] ?? "");

    
    $newPass = $_POST["new_password"] ?? "";
    if ($newPass !== "") {
        
        $stmt = $mysqli->prepare("UPDATE member SET name=?, address=?, email=?, c_no=?, gender=?, bmi=?, password=? WHERE m_id=?");
        $stmt->bind_param("sssssssi", $name, $address, $email, $c_no, $gender, $bmi, $hash, $m_id);
    } else {
        $stmt = $mysqli->prepare("UPDATE member SET name=?, address=?, email=?, c_no=?, gender=?, bmi=? WHERE m_id=?");
        $stmt->bind_param("ssssssi", $name, $address, $email, $c_no, $gender, $bmi, $m_id);
    }
    $stmt->execute();
    $_SESSION["name"] = $name;
    $msg = "Profile updated.";
}

$stmt = $mysqli->prepare("SELECT * FROM member WHERE m_id=?");
$stmt->bind_param("i", $m_id);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();

include __DIR__ . "/../partials/header.php";
?>
<div class="card">
  <h1>Update Profile</h1>
  <?php if ($msg): ?><div class="msg"><?= h($msg) ?></div><?php endif; ?>

  <form method="post">
    <div class="grid">
      <div class="col-6"><label>Name</label><input name="name" value="<?= h($row["name"]) ?>" required></div>
      <div class="col-6"><label>Email</label><input type="email" name="email" value="<?= h($row["email"]) ?>" required></div>
      <div class="col-6"><label>Contact No</label><input name="c_no" value="<?= h($row["c_no"]) ?>"></div>
      <div class="col-6"><label>Gender</label><input name="gender" value="<?= h($row["gender"]) ?>"></div>
      <div class="col-6"><label>BMI</label><input name="bmi" value="<?= h((string)$row["bmi"]) ?>"></div>
      <div class="col-6"><label>New Password (optional)</label><input type="password" name="new_password"></div>
      <div class="col-12"><label>Address</label><input name="address" value="<?= h($row["address"]) ?>"></div>

      <div class="col-12 row">
        <button class="btn btn-primary" type="submit">Save</button>
        <a class="btn" href="<?= h($base) ?>/member/home.php">Back</a>
      </div>
    </div>
  </form>
</div>
<?php include __DIR__ . "/../partials/footer.php"; ?>
