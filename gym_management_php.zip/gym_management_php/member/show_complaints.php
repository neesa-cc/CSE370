<?php
require_once __DIR__ . "/../config/auth.php";
require_login(["member"]);

$title = "My Complaints";
$base  = get_base_url();
$m_id  = current_user_id();


$sql = "
SELECT 
  c.m_id, c.e_id, c.t_id, c.comment,
  e.name AS equipment_name,
  t.name AS trainer_name
FROM complains c
LEFT JOIN equipment e ON e.e_id = c.e_id
LEFT JOIN trainer t   ON t.t_id = c.t_id
WHERE c.m_id = ?
ORDER BY c.e_id DESC, c.t_id DESC
";

$stmt = $mysqli->prepare($sql);
$stmt->bind_param("i", $m_id);
$stmt->execute();
$res = $stmt->get_result();

include __DIR__ . "/../partials/header.php";
?>
<div class="card">
  <h1>My Complaints</h1>

  <div class="row">
    <a class="btn btn-primary" href="<?= h($base) ?>/member/insert_complaint.php">+ Add Complaint</a>
    <a class="btn" href="<?= h($base) ?>/member/home.php">Back</a>
  </div>

  <table>
    <thead>
      <tr>
        <th>Equipment</th>
        <th>Trainer</th>
        <th>Comment</th>
        <th>Action</th>
      </tr>
    </thead>

    <tbody>
      <?php if ($res->num_rows === 0): ?>
        <tr>
          <td colspan="4" class="muted">No complaints found.</td>
        </tr>
      <?php else: ?>
        <?php while($r = $res->fetch_assoc()): ?>
          <tr>
            <td><?= h($r["equipment_name"] ?? "Unknown") ?> (<?= h($r["e_id"]) ?>)</td>
            <td><?= h($r["trainer_name"] ?? "Unknown") ?> (<?= h($r["t_id"]) ?>)</td>
            <td><?= h($r["comment"]) ?></td>

            <td class="row">
              <a class="btn btn-danger"
                 href="<?= h($base) ?>/member/delete_complaint.php?e_id=<?= h($r["e_id"]) ?>&t_id=<?= h($r["t_id"]) ?>"
                 onclick="return confirm('Delete this complaint?')">
                 Delete
              </a>
            </td>
          </tr>
        <?php endwhile; ?>
      <?php endif; ?>
    </tbody>
  </table>
</div>
<?php include __DIR__ . "/../partials/footer.php"; ?>


