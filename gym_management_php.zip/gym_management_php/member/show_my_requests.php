<?php
require_once __DIR__ . "/../config/auth.php";
require_login(["member"]);
$title = "My Requests";
$base = get_base_url();
$m_id = current_user_id();


$sqlT = "SELECT t.t_id, t.name, t.availability
         FROM member m
         LEFT JOIN trainer t ON t.t_id = m.t_id
         WHERE m.m_id=?";
$stmtT = $mysqli->prepare($sqlT);
$stmtT->bind_param("i", $m_id);
$stmtT->execute();
$trainer = $stmtT->get_result()->fetch_assoc();


$sql = "
SELECT mr.e_id, mr.req_status, e.name AS equipment_name
FROM member_req mr
LEFT JOIN equipment e ON e.e_id = mr.e_id
WHERE mr.m_id=?
ORDER BY mr.e_id DESC";
$stmt = $mysqli->prepare($sql);
$stmt->bind_param("i", $m_id);
$stmt->execute();
$res = $stmt->get_result();

include __DIR__ . "/../partials/header.php";
?>
<div class="card">
  <h1>My Requests</h1>

  <div class="card" style="margin-top:12px">
    <h2>Assigned Trainer</h2>
    <?php if (!empty($trainer["t_id"])): ?>
      <p><b><?= h($trainer["name"]) ?></b> (ID: <?= h($trainer["t_id"]) ?>) — Available: <?= h($trainer["availability"] ?? "Not set") ?></p>
    <?php else: ?>
      <p class="muted">No trainer selected yet.</p>
    <?php endif; ?>
    <a class="btn btn-primary" href="<?= h($base) ?>/member/request_trainer.php">Request / Change Trainer</a>
  </div>

  <div class="card" style="margin-top:12px">
    <h2>Equipment Requests</h2>
    <div class="row">
      <a class="btn btn-primary" href="<?= h($base) ?>/member/request_equipment.php">+ Request Equipment</a>
      <a class="btn" href="<?= h($base) ?>/member/home.php">Back</a>
    </div>

    <table>
      <thead><tr><th>Equipment</th><th>Status</th><th>Action</th></tr></thead>
      <tbody>
        <?php if ($res->num_rows === 0): ?>
          <tr><td colspan="3" class="muted">No equipment requests found.</td></tr>
        <?php else: ?>
          <?php while($r = $res->fetch_assoc()): ?>
          <tr>
            <td><?= h($r["equipment_name"] ?? "") ?> (<?= h($r["e_id"]) ?>)</td>
            <td><?= h($r["req_status"]) ?></td>
            <td>
              <a class="btn btn-danger"
                 href="<?= h($base) ?>/member/cancel_request.php?e_id=<?= h($r["e_id"]) ?>"
                 onclick="return confirm('Cancel this request?')">Cancel</a>
            </td>
          </tr>
          <?php endwhile; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php include __DIR__ . "/../partials/footer.php"; ?>

