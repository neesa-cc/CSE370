<?php
require_once __DIR__ . "/../config/auth.php";
require_login(["member"]);
$title = "Member Home";
$base = get_base_url();
include __DIR__ . "/../partials/header.php";
include __DIR__ . "/../partials/alerts_widget.php";

?>
<div class="card">
  <h1>Member Panel</h1>
  <div class="row">
    <a class="btn" href="<?= h($base) ?>/member/update_profile.php">Update Profile</a>
    <a class="btn btn-primary" href="<?= h($base) ?>/member/request_trainer.php">Request Trainer</a>
<a class="btn btn-primary" href="<?= h($base) ?>/member/request_equipment.php">Request Equipment</a>
    <a class="btn" href="<?= h($base) ?>/member/show_my_requests.php">My Requests</a>
    <a class="btn" href="<?= h($base) ?>/member/insert_complaint.php">File Complaint</a>
    <a class="btn" href="<?= h($base) ?>/member/show_complaints.php">My Complaints</a>
    <a class="btn" href="<?= h($base) ?>/member/insert_payment.php">Make Payment</a>
    <a class="btn" href="<?= h($base) ?>/member/show_payments.php">Payment History</a>
     
  </div>
</div>
<?php include __DIR__ . "/../partials/footer.php"; ?>
