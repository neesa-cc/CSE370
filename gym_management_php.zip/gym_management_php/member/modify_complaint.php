<?php
require_once __DIR__ . "/../config/auth.php";
require_login(["member"]);
$title = "Modify Complaint";
$base = get_base_url();
$m_id = current_user_id();

$e_id = (int)($_GET["e_id"] ?? 0);
$t_id = (int)($_GET["t_id"] ?? 0);

$stmt = $mysqli->prepare("SELECT comment FROM complains WHERE m_id=? AND e_id=? AND t_id=?");
$stmt->bind_param("iii", $m_id, $e_id, $t_id);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();
if (!$row) die("Complaint not found.");

include __DIR__ . "/../partials/header.php";
?>
<div class="card">
  <h1>Edit Complaint</h1>
  <p class="muted">e_id: <?= h($e_id) ?> | t_id: <?= h($t_id) ?></p>

  <form method="post" action="<?= h($base) ?>/member/update_complaint.php">
    <input type="hidden" name="e_id" value="<?= h($e_id) ?>">
    <input type="hidden" name="t_id" value="<?= h($t_id) ?>">

    <label>Comment</label>
    <textarea name="comment" required><?= h($row["comment"]) ?></textarea>

    <div class="row" style="margin-top:12px">
      <button class="btn btn-primary" type="submit">Update</button>
      <a class="btn" href="<?= h($base) ?>/member/show_complaints.php">Back</a>
    </div>
  </form>
</div>
<?php include __DIR__ . "/../partials/footer.php"; ?>
