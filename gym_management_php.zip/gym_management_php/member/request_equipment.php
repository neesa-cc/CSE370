<?php
require_once __DIR__ . "/../config/auth.php";
require_login(["member"]);
$title = "Request Equipment";
$base = get_base_url();
$m_id = current_user_id();
$msg = "";

$equip = $mysqli->query("SELECT e_id, name, quantity FROM equipment ORDER BY name");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $e_id = (int)($_POST["e_id"] ?? 0);

    $sql = "INSERT INTO member_req (m_id, e_id, req_status)
            VALUES (?, ?, 'pending')
            ON DUPLICATE KEY UPDATE req_status='pending'";
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param("ii", $m_id, $e_id);
    $stmt->execute();

    $msg = "Equipment request sent (pending).";
}

include __DIR__ . "/../partials/header.php";
?>
<div class="card">
  <h1>Request Equipment</h1>
  <p class="muted">This is independent from trainer request. It uses member_req table.</p>

  <?php if ($msg): ?><div class="msg"><?= h($msg) ?></div><?php endif; ?>

  <form method="post">
    <label>Select Equipment</label>
    <select name="e_id" required>
      <option value="">-- choose --</option>
      <?php while($e = $equip->fetch_assoc()): ?>
        <option value="<?= h($e["e_id"]) ?>">
          <?= h($e["name"]) ?> (Qty: <?= h($e["quantity"]) ?>)
        </option>
      <?php endwhile; ?>
    </select>

    <div class="row" style="margin-top:12px">
      <button class="btn btn-primary" type="submit">Request Equipment</button>
      <a class="btn" href="<?= h($base) ?>/member/home.php">Back</a>
    </div>
  </form>
</div>
<?php include __DIR__ . "/../partials/footer.php"; ?>
