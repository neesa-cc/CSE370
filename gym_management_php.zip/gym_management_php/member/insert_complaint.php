
<?php
require_once __DIR__ . "/../config/auth.php";
require_login(["member"]);
$title = "File Complaint";
$base = get_base_url();
$m_id = current_user_id();
$msg = "";


$stmt = $mysqli->prepare("SELECT t_id FROM member WHERE m_id=?");
$stmt->bind_param("i", $m_id);
$stmt->execute();
$mem = $stmt->get_result()->fetch_assoc();
$assigned_t = (int)($mem["t_id"] ?? 0);

$equip = $mysqli->query("SELECT e_id, name FROM equipment ORDER BY name");
$trainers = $mysqli->query("SELECT t_id, name FROM trainer ORDER BY name");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $e_id = (int)($_POST["e_id"] ?? 0);
    $t_id = (int)($_POST["t_id"] ?? $assigned_t);
    $comment = trim($_POST["comment"] ?? "");

    $sql = "INSERT INTO complains (m_id, e_id, t_id, comment) VALUES (?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE comment=VALUES(comment)";
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param("iiis", $m_id, $e_id, $t_id, $comment);
    $stmt->execute();
    $msg = "Complaint saved.";
}

include __DIR__ . "/../partials/header.php";
?>
<div class="card">
  <h1>File Complaint</h1>
  <?php if ($msg): ?><div class="msg"><?= h($msg) ?></div><?php endif; ?>

  <form method="post">
    <div class="grid">
      <div class="col-6">
        <label>Equipment</label>
        <select name="e_id" required>
          <option value="">-- choose --</option>
          <?php while($e = $equip->fetch_assoc()): ?>
            <option value="<?= h($e["e_id"]) ?>"><?= h($e["name"]) ?></option>
          <?php endwhile; ?>
        </select>
      </div>

      <div class="col-6">
        <label>Trainer</label>
        <select name="t_id" required>
          <option value="">-- choose --</option>
          <?php while($t = $trainers->fetch_assoc()): ?>
            <option value="<?= h($t["t_id"]) ?>" <?= ($assigned_t === (int)$t["t_id"]) ? "selected" : "" ?>>
              <?= h($t["name"]) ?><?= ($assigned_t === (int)$t["t_id"]) ? " (assigned)" : "" ?>
            </option>
          <?php endwhile; ?>
        </select>
      </div>

      <div class="col-12">
        <label>Complaint / Comment</label>
        <textarea name="comment" required></textarea>
      </div>

      <div class="col-12 row">
        <button class="btn btn-primary" type="submit">Submit</button>
        <a class="btn" href="<?= h($base) ?>/member/home.php">Back</a>
      </div>
    </div>
  </form>
</div>
<?php include __DIR__ . "/../partials/footer.php"; ?>
