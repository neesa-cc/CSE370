<?php
require_once __DIR__ . "/../config/auth.php";
require_login(["member"]);
$title = "Payment History";
$base = get_base_url();
$m_id = current_user_id();

$stmt = $mysqli->prepare("SELECT p_id, date, status FROM payment WHERE m_id=? ORDER BY p_id DESC");
$stmt->bind_param("i", $m_id);
$stmt->execute();
$res = $stmt->get_result();

include __DIR__ . "/../partials/header.php";
?>
<div class="card">
  <h1>Payment History</h1>
  <div class="row">
    <a class="btn btn-primary" href="<?= h($base) ?>/member/insert_payment.php">+ Add Payment</a>
    <a class="btn" href="<?= h($base) ?>/member/home.php">Back</a>
  </div>

  <table>
    <thead><tr><th>ID</th><th>Date</th><th>Status</th><th>Action</th></tr></thead>
    <tbody>
    <?php while($r = $res->fetch_assoc()): ?>
      <tr>
        <td><?= h($r["p_id"]) ?></td>
        <td><?= h($r["date"]) ?></td>
        <td><?= h($r["status"]) ?></td>
        <td>
          <?php if ($r["status"] === "pending"): ?>
            <a class="btn btn-danger" href="<?= h($base) ?>/member/cancel_payment.php?p_id=<?= h($r["p_id"]) ?>">Cancel</a>
          <?php else: ?>
            <span class="muted">—</span>
          <?php endif; ?>
        </td>
      </tr>
    <?php endwhile; ?>
    </tbody>
  </table>
</div>
<?php include __DIR__ . "/../partials/footer.php"; ?>
