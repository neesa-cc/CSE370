<?php
require_once __DIR__ . "/../config/auth.php";
require_login(["member"]);
$title = "Request Trainer";
$base = get_base_url();
$m_id = current_user_id();
$msg = "";


$trainers = $mysqli->query("SELECT t_id, name, availability FROM trainer ORDER BY name");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $t_id = (int)($_POST["t_id"] ?? 0);

    $stmt = $mysqli->prepare("UPDATE member SET t_id=? WHERE m_id=?");
    $stmt->bind_param("ii", $t_id, $m_id);
    $stmt->execute();

    $msg = "Trainer requested/assigned successfully.";
}

include __DIR__ . "/../partials/header.php";
?>
<div class="card">
  <h1>Request Trainer</h1>
  <p class="muted">This is independent from equipment request. It assigns trainer using member.t_id (schema-based).</p>

  <?php if ($msg): ?><div class="msg"><?= h($msg) ?></div><?php endif; ?>

  <form method="post">
    <label>Select Trainer</label>
    <select name="t_id" required>
      <option value="">-- choose --</option>
      <?php while($t = $trainers->fetch_assoc()): ?>
        <option value="<?= h($t["t_id"]) ?>">
          <?= h($t["name"]) ?> (Available: <?= h($t["availability"] ?? "Not set") ?>)
        </option>
      <?php endwhile; ?>
    </select>

    <div class="row" style="margin-top:12px">
      <button class="btn btn-primary" type="submit">Request Trainer</button>
      <a class="btn" href="<?= h($base) ?>/member/home.php">Back</a>
    </div>
  </form>
</div>
<?php include __DIR__ . "/../partials/footer.php"; ?>

