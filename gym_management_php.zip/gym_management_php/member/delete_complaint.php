<?php
require_once __DIR__ . "/../config/auth.php";
require_login(["member"]);

$base = get_base_url();
$m_id = current_user_id();

$e_id = (int)($_GET["e_id"] ?? 0);
$t_id = (int)($_GET["t_id"] ?? 0);

if ($e_id <= 0 || $t_id <= 0) {
    die("Invalid complaint");
}

$stmt = $mysqli->prepare("DELETE FROM complains WHERE m_id=? AND e_id=? AND t_id=?");
$stmt->bind_param("iii", $m_id, $e_id, $t_id);
$stmt->execute();

redirect($base . "/member/show_complaints.php");


