<?php
require_once __DIR__ . "/../config/auth.php";
require_login(["member"]);
$base = get_base_url();
$m_id = current_user_id();

$e_id = (int)($_POST["e_id"] ?? 0);
$t_id = (int)($_POST["t_id"] ?? 0);
$comment = trim($_POST["comment"] ?? "");

$stmt = $mysqli->prepare("UPDATE complains SET comment=? WHERE m_id=? AND e_id=? AND t_id=?");
$stmt->bind_param("siii", $comment, $m_id, $e_id, $t_id);
$stmt->execute();

redirect($base . "/member/show_complaints.php");
