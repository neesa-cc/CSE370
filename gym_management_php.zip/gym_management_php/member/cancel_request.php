<?php
require_once __DIR__ . "/../config/auth.php";
require_login(["member"]);
$base = get_base_url();
$m_id = current_user_id();
$e_id = (int)($_GET["e_id"] ?? 0);

$stmt = $mysqli->prepare("UPDATE member_req SET req_status='cancelled' WHERE m_id=? AND e_id=?");
$stmt->bind_param("ii", $m_id, $e_id);
$stmt->execute();

redirect($base . "/member/show_my_requests.php");
