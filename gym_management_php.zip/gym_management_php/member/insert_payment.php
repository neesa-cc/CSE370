<?php
require_once __DIR__ . "/../config/auth.php";
require_login(["member"]);
$title = "Make Payment";
$base = get_base_url();
$m_id = current_user_id();
$msg = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $date = $_POST["date"] ?? date("Y-m-d");
    $status = trim($_POST["status"] ?? "pending");

    $stmt = $mysqli->prepare("INSERT INTO payment (date, status, m_id) VALUES (?, ?, ?)");
    $stmt->bind_param("ssi", $date, $status, $m_id);
    $stmt->execute();
    $msg = "Payment record added.";
}

include __DIR__ . "/../partials/header.php";
?>
<div class="card">
  <h1>Payment</h1>
  <?php if ($msg): ?><div class="msg"><?= h($msg) ?></div><?php endif; ?>

  <form method="post">
    <div class="grid">
      <div class="col-6">
        <label>Date</label>
        <input type="date" name="date" value="<?= h(date("Y-m-d")) ?>">
      </div>
      <div class="col-6">
        <label>Status</label>
        <select name="status">
          <option value="pending">pending</option>
          <option value="paid">paid</option>
          <option value="cancelled">cancelled</option>
        </select>
      </div>
      <div class="col-12 row">
        <button class="btn btn-primary" type="submit">Save</button>
        <a class="btn" href="<?= h($base) ?>/member/show_payments.php">Back</a>
      </div>
    </div>
  </form>
</div>
<?php include __DIR__ . "/../partials/footer.php"; ?>
