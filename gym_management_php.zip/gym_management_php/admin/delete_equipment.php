<?php
require_once __DIR__ . "/../config/auth.php";
require_login(["admin"]);
$base = get_base_url();

$e_id = (int)($_GET["e_id"] ?? 0);
if ($e_id <= 0) die("Invalid equipment id");

$stmt = $mysqli->prepare("DELETE FROM equipment WHERE e_id=?");
$stmt->bind_param("i", $e_id);
$stmt->execute();

redirect($base . "/admin/show_equipment.php");
