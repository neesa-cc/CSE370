<?php
require_once __DIR__ . "/../config/auth.php";
require_login(["admin"]);

$title = "Alert History";
$base  = get_base_url();

$res = $mysqli->query("SELECT a_id, name, status FROM alert ORDER BY a_id DESC");

include __DIR__ . "/../partials/header.php";
?>
<div class="card">
  <h1>Alert History</h1>

  <div class="row">
    <a class="btn btn-primary" href="<?= h($base) ?>/admin/insert_alert.php">+ Create Alert</a>
    <a class="btn" href="<?= h($base) ?>/admin/home.php">Admin Home</a>
  </div>

  <table>
    <thead>
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Status</th>
        <th>Action</th>
      </tr>
    </thead>

    <tbody>
      <?php if ($res && $res->num_rows === 0): ?>
        <tr><td colspan="4" class="muted">No alerts found.</td></tr>
      <?php else: ?>
        <?php while($row = $res->fetch_assoc()): ?>
          <tr>
            <td><?= h($row["a_id"]) ?></td>
            <td><?= h($row["name"]) ?></td>
            <td><?= h($row["status"]) ?></td>

            <td class="row">
              
              <a class="btn btn-danger"
                 href="<?= h($base) ?>/admin/delete_alert.php?a_id=<?= h($row["a_id"]) ?>"
                 onclick="return confirm('Delete this alert?')">
                 Delete
              </a>
            </td>
          </tr>
        <?php endwhile; ?>
      <?php endif; ?>
    </tbody>
  </table>
</div>
<?php include __DIR__ . "/../partials/footer.php"; ?>
