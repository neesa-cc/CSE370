<?php
require_once __DIR__ . "/../config/auth.php";
require_login(["admin"]);

$title = "Equipment Requests";
$base  = get_base_url();


$res = $mysqli->query($sql);
if (!$res) {
    die("SQL Error: " . h($mysqli->error));
}

include __DIR__ . "/../partials/header.php";
?>
<div class="card">
  <h1>Member Equipment Requests</h1>
  <p class="muted">Approve/Decline buttons appear only for <b>pending</b> requests.</p>

  <div class="row">
    <a class="btn" href="<?= h($base) ?>/admin/home.php">Admin Home</a>
  </div>

  <table>
    <thead>
      <tr>
        <th>Member</th>
        <th>Email</th>
        <th>Equipment</th>
        <th>Status</th>
        <th>Action</th>
      </tr>
    </thead>

    <tbody>
      <?php if ($res->num_rows === 0): ?>
        <tr><td colspan="5" class="muted">No requests found.</td></tr>
      <?php else: ?>
        <?php while($r = $res->fetch_assoc()): ?>
          <tr>
            <td><?= h($r["member_name"]) ?> (<?= h($r["m_id"]) ?>)</td>
            <td><?= h($r["member_email"]) ?></td>
            <td><?= h($r["equipment_name"] ?? "") ?> (<?= h($r["e_id"]) ?>)</td>
            <td><?= h($r["req_status"]) ?></td>

            <td class="row">
              <?php if (($r["req_status"] ?? "") === "pending"): ?>
                <a class="btn btn-primary"
                   href="<?= h($base) ?>/admin/update_equipment_request.php?m_id=<?= h($r["m_id"]) ?>&e_id=<?= h($r["e_id"]) ?>&status=approved">
                   Approve
                </a>

                <a class="btn btn-danger"
                   href="<?= h($base) ?>/admin/update_equipment_request.php?m_id=<?= h($r["m_id"]) ?>&e_id=<?= h($r["e_id"]) ?>&status=declined"
                   onclick="return confirm('Decline this request?')">
                   Decline
                </a>
              <?php else: ?>
                <span class="muted">Processed</span>
              <?php endif; ?>
            </td>
          </tr>
        <?php endwhile; ?>
      <?php endif; ?>
    </tbody>
  </table>
</div>
<?php include __DIR__ . "/../partials/footer.php"; ?>
