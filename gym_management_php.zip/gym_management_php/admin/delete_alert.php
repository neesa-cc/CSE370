<?php
require_once __DIR__ . "/../config/auth.php";
require_login(["admin"]);

$base = get_base_url();

$a_id = (int)($_GET["a_id"] ?? 0);
if ($a_id <= 0) {
    die("Invalid alert id");
}

$stmt = $mysqli->prepare("DELETE FROM alert WHERE a_id=?");
$stmt->bind_param("i", $a_id);
$stmt->execute();

redirect($base . "/admin/show_alert.php");
