<?php
require_once __DIR__ . "/../config/auth.php";
require_login(["admin"]);
$title = "Members (Admin)";
$base = get_base_url();

/*
Show members + assigned trainer + latest payment status
*/
$sql = "
SELECT
  m.m_id, m.name, m.email, m.c_no, m.gender, m.bmi,
  t.name AS trainer_name,
  lp.status AS last_payment_status,
  lp.date   AS last_payment_date
FROM member m
LEFT JOIN trainer t ON t.t_id = m.t_id
LEFT JOIN (
  SELECT p1.m_id, p1.status, p1.date
  FROM payment p1
  INNER JOIN (
    SELECT m_id, MAX(p_id) AS max_p_id
    FROM payment
    GROUP BY m_id
  ) x ON x.m_id = p1.m_id AND x.max_p_id = p1.p_id
) lp ON lp.m_id = m.m_id
ORDER BY m.m_id DESC
";
$res = $mysqli->query($sql);

include __DIR__ . "/../partials/header.php";
?>
<div class="card">
  <h1>Members (Admin)</h1>
  <div class="row">
    <a class="btn" href="<?= h($base) ?>/admin/home.php">Back</a>
  </div>

  <table>
    <thead>
      <tr>
        <th>m_id</th>
        <th>Name</th>
        <th>Email</th>
        <th>Contact</th>
        <th>Trainer</th>
        <th>Last Payment</th>
        <th>Payment Date</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php while($r = $res->fetch_assoc()): ?>
        <tr>
          <td><?= h($r["m_id"]) ?></td>
          <td><?= h($r["name"]) ?></td>
          <td><?= h($r["email"]) ?></td>
          <td><?= h($r["c_no"]) ?></td>
          <td><?= h($r["trainer_name"] ?? "Not assigned") ?></td>
          <td><?= h($r["last_payment_status"] ?? "No payment") ?></td>
          <td><?= h($r["last_payment_date"] ?? "-") ?></td>
          <td class="row">
            <a class="btn btn-danger"
               href="<?= h($base) ?>/admin/cancel_membership.php?m_id=<?= h($r["m_id"]) ?>"
               onclick="return confirm('Cancel membership for this member?');">
               Cancel Membership
            </a>
          </td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>
<?php include __DIR__ . "/../partials/footer.php"; ?>
