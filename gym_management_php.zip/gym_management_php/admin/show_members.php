<?php
require_once __DIR__ . "/../config/auth.php";
require_login(["admin"]);
$title = "Members (Admin)";
$base = get_base_url();

$res = $mysqli->query($sql);

include __DIR__ . "/../partials/header.php";
?>
<div class="card">
  <h1>Members (Admin)</h1>
  <div class="row">
    <a class="btn" href="<?= h($base) ?>/admin/home.php">Back</a>
  </div>

  <table>
    <thead>
      <tr>
        <th>m_id</th>
        <th>Name</th>
        <th>Email</th>
        <th>Contact</th>
        <th>Trainer</th>
        <th>Last Payment</th>
        <th>Payment Date</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php while($r = $res->fetch_assoc()): ?>
        <tr>
          <td><?= h($r["m_id"]) ?></td>
          <td><?= h($r["name"]) ?></td>
          <td><?= h($r["email"]) ?></td>
          <td><?= h($r["c_no"]) ?></td>
          <td><?= h($r["trainer_name"] ?? "Not assigned") ?></td>
          <td><?= h($r["last_payment_status"] ?? "No payment") ?></td>
          <td><?= h($r["last_payment_date"] ?? "-") ?></td>
          <td class="row">
            <a class="btn btn-danger"
               href="<?= h($base) ?>/admin/cancel_membership.php?m_id=<?= h($r["m_id"]) ?>"
               onclick="return confirm('Cancel membership for this member?');">
               Cancel Membership
            </a>
          </td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>
<?php include __DIR__ . "/../partials/footer.php"; ?>
