<?php
require_once __DIR__ . "/../config/auth.php";
require_login(["admin"]);
$title = "Admin Home";
$base = get_base_url();
include __DIR__ . "/../partials/header.php";
?>
<div class="card">
  <h1>Admin Panel</h1>
  <div class="row">
    <a class="btn btn-primary" href="<?= h($base) ?>/admin/insert_equipment.php">Add Equipment</a>
    <a class="btn" href="<?= h($base) ?>/admin/show_equipment.php">View Equipment</a>
    <a class="btn btn-primary" href="<?= h($base) ?>/admin/insert_alert.php">Create Alert</a>
    <a class="btn" href="<?= h($base) ?>/admin/show_alert.php">View Alerts</a>
    <a class="btn btn-danger" href="<?= h($base) ?>/admin/manage_membership.php">Manage Membership</a>
    <a class="btn" href="<?= h($base) ?>/admin/show_equipment_requests.php">Equipment Requests</a>
    <a class="btn" href="<?= h($base) ?>/admin/show_equipment.php">Show All Equipment</a>

  </div>
</div>
<?php include __DIR__ . "/../partials/footer.php"; ?>
