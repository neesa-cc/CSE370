<?php
require_once __DIR__ . "/../config/auth.php";
require_login(["admin"]);

$title = "All Equipment";
$base  = get_base_url();

$sql = "SELECT e_id, name, warrenty, quantity, p_date, rating
        FROM equipment
        ORDER BY e_id DESC";
$res = $mysqli->query($sql);

include __DIR__ . "/../partials/header.php";
?>
<div class="card">
  <h1>All Equipment</h1>

  <div class="row">
    <a class="btn btn-primary" href="<?= h($base) ?>/admin/insert_equipment.php">+ Add Equipment</a>
    <a class="btn" href="<?= h($base) ?>/admin/home.php">Admin Home</a>
  </div>

  <table>
    <thead>
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Warranty</th>
        <th>Qty</th>
        <th>Purchase Date</th>
        <th>Rating</th>
        <th>Action</th>
      </tr>
    </thead>

    <tbody>
      <?php if ($res && $res->num_rows === 0): ?>
        <tr><td colspan="7" class="muted">No equipment found.</td></tr>
      <?php else: ?>
        <?php while($row = $res->fetch_assoc()): ?>
          <tr>
            <td><?= h($row["e_id"]) ?></td>
            <td><?= h($row["name"]) ?></td>
            <td><?= h($row["warrenty"]) ?></td>
            <td><?= h($row["quantity"]) ?></td>
            <td><?= h($row["p_date"]) ?></td>
            <td><?= h($row["rating"]) ?></td>

            <td class="row">
              <a class="btn btn-danger"
                 href="<?= h($base) ?>/admin/delete_equipment.php?e_id=<?= h($row["e_id"]) ?>"
                 onclick="return confirm('Delete this equipment?')">
                 Delete
              </a>
            </td>
          </tr>
        <?php endwhile; ?>
      <?php endif; ?>
    </tbody>
  </table>
</div>
<?php include __DIR__ . "/../partials/footer.php"; ?>

