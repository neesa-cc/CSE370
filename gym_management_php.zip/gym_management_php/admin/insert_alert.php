<?php
require_once __DIR__ . "/../config/auth.php";
require_login(["admin"]);

$title = "Create Alert";
$base  = get_base_url();

$msg = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST["name"] ?? "");

    if ($name !== "") {
        $status = "active"; // default
        $stmt = $mysqli->prepare("INSERT INTO alert (name, status) VALUES (?, ?)");
        $stmt->bind_param("ss", $name, $status);
        $stmt->execute();

        $msg = "Alert created.";
    } else {
        $msg = "Please enter alert message.";
    }
}

include __DIR__ . "/../partials/header.php";
?>
<div class="card">
  <h1>Create Alert</h1>

  <?php if ($msg): ?><div class="msg"><?= h($msg) ?></div><?php endif; ?>

  <form method="post">
    <label>Alert Message</label>
    <input type="text" name="name" required placeholder="e.g. Public Holiday Tomorrow">

    <div class="row" style="margin-top:12px">
      <button class="btn btn-primary" type="submit">Create</button>
      <a class="btn" href="<?= h($base) ?>/admin/show_alert.php">Back</a>
    </div>
  </form>
</div>
<?php include __DIR__ . "/../partials/footer.php"; ?>
