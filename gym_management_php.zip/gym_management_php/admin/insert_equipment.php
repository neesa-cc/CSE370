<?php
require_once __DIR__ . "/../config/auth.php";
require_login(["admin"]);
$title = "Add Equipment";
$base = get_base_url();

$msg = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST["name"] ?? "");
    $warrenty = trim($_POST["warrenty"] ?? "");
    $quantity = (int)($_POST["quantity"] ?? 0);
    $p_date = $_POST["p_date"] ?? null;
    $rating = trim($_POST["rating"] ?? "");
    $a_id = current_user_id();

    $sql = "INSERT INTO equipment (name, warrenty, quantity, p_date, rating, a_id)
            VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param("ssissi", $name, $warrenty, $quantity, $p_date, $rating, $a_id);
    $stmt->execute();
    $msg = "Equipment added successfully.";
}

include __DIR__ . "/../partials/header.php";
?>
<div class="card">
  <h1>Add Equipment</h1>

  <?php if ($msg): ?><div class="msg"><?= h($msg) ?></div><?php endif; ?>

  <form method="post">
    <div class="grid">
      <div class="col-6">
        <label>Name</label>
        <input name="name" required>
      </div>
      <div class="col-6">
        <label>Warranty</label>
        <input name="warrenty">
      </div>
      <div class="col-6">
        <label>Quantity</label>
        <input type="number" name="quantity" min="0" value="1">
      </div>
      <div class="col-6">
        <label>Purchase Date</label>
        <input type="date" name="p_date">
      </div>
      <div class="col-12">
        <label>Rating</label>
        <input name="rating" placeholder="e.g. Good">
      </div>

      <div class="col-12 row">
        <button class="btn btn-primary" type="submit">Save</button>
        <a class="btn" href="<?= h($base) ?>/admin/show_equipment.php">Back</a>
      </div>
    </div>
  </form>
</div>
<?php include __DIR__ . "/../partials/footer.php"; ?>
