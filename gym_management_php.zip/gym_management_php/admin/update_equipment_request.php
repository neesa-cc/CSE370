<?php
require_once __DIR__ . "/../config/auth.php";
require_login(["admin"]);

$base = get_base_url();

$m_id = (int)($_GET["m_id"] ?? 0);
$e_id = (int)($_GET["e_id"] ?? 0);
$status = trim($_GET["status"] ?? "");

$allowed = ["approved", "declined", "pending"];
if ($m_id <= 0 || $e_id <= 0 || !in_array($status, $allowed, true)) {
    die("Invalid request");
}

$stmt = $mysqli->prepare("UPDATE member_req SET req_status=? WHERE m_id=? AND e_id=?");
$stmt->bind_param("sii", $status, $m_id, $e_id);
$stmt->execute();

redirect($base . "/admin/show_equipment_requests.php");

