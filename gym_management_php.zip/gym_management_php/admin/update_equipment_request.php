<?php
require_once __DIR__ . "/../config/auth.php";
require_login(["admin"]);
$title = "Equipment Requests";
$base = get_base_url();


$sql = "
SELECT 
  mr.m_id, mr.e_id, mr.req_status,
  m.name AS member_name, m.email AS member_email,
  e.name AS equipment_name
FROM member_req mr
JOIN member m ON m.m_id = mr.m_id
LEFT JOIN equipment e ON e.e_id = mr.e_id
ORDER BY mr.m_id DESC, mr.e_id DESC
";
$res = $mysqli->query($sql);

include __DIR__ . "/../partials/header.php";
?>
<div class="card">
  <h1>Member Equipment Requests</h1>
  <p class="muted">This page shows requests stored in <b>member_req</b>.</p>

  <div class="row">
    <a class="btn" href="<?= h($base) ?>/admin/home.php">Admin Home</a>
  </div>

  <table>
    <thead>
      <tr>
        <th>Member</th>
        <th>Email</th>
        <th>Equipment</th>
        <th>Status</th>
      </tr>
    </thead>
    <tbody>
      <?php if ($res->num_rows === 0): ?>
        <tr><td colspan="4" class="muted">No requests found.</td></tr>
      <?php else: ?>
        <?php while($r = $res->fetch_assoc()): ?>
          <tr>
            <td><?= h($r["member_name"]) ?> (<?= h($r["m_id"]) ?>)</td>
            <td><?= h($r["member_email"]) ?></td>
            <td><?= h($r["equipment_name"] ?? "") ?> (<?= h($r["e_id"]) ?>)</td>
            <td><?= h($r["req_status"]) ?></td>
          </tr>
        <?php endwhile; ?>
      <?php endif; ?>
    </tbody>
  </table>
</div>
<?php include __DIR__ . "/../partials/footer.php"; ?>

