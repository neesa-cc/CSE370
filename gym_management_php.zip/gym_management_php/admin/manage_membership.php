<?php
require_once __DIR__ . "/../config/auth.php";
require_login(["admin"]);
$title = "Manage Membership";
$base = get_base_url();

$res = $mysqli->query($sql);

include __DIR__ . "/../partials/header.php";
?>
<div class="card">
  <h1>Manage Membership</h1>
  <p class="muted">Admin can cancel membership by setting latest payment status to <b>cancelled</b>.</p>

  <div class="row">
    <a class="btn" href="<?= h($base) ?>/admin/home.php">Admin Home</a>
  </div>

  <table>
    <thead>
      <tr>
        <th>Member ID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Contact</th>
        <th>Gender</th>
        <th>BMI</th>
        <th>Last Payment Date</th>
        <th>Last Payment Status</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
    <?php while($r = $res->fetch_assoc()): ?>
      <tr>
        <td><?= h($r["m_id"]) ?></td>
        <td><?= h($r["name"]) ?></td>
        <td><?= h($r["email"]) ?></td>
        <td><?= h($r["c_no"]) ?></td>
        <td><?= h($r["gender"]) ?></td>
        <td><?= h((string)$r["bmi"]) ?></td>
        <td><?= h($r["last_payment_date"] ?? "—") ?></td>
        <td><?= h($r["last_payment_status"] ?? "no record") ?></td>
        <td class="row">
          <a class="btn btn-danger"
             href="<?= h($base) ?>/admin/cancel_membership.php?m_id=<?= h($r["m_id"]) ?>"
             onclick="return confirm('Cancel membership for this member?')">
             Cancel Membership
          </a>
        </td>
      </tr>
    <?php endwhile; ?>
    </tbody>
  </table>
</div>
<?php include __DIR__ . "/../partials/footer.php"; ?>

