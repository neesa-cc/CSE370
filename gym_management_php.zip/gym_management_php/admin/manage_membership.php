<?php
require_once __DIR__ . "/../config/auth.php";
require_login(["admin"]);

$title = "Manage Membership";
$base  = get_base_url();
$sql = "
SELECT 
  m.m_id, m.name, m.email, m.c_no, m.gender, m.bmi,
  p.date   AS last_payment_date,
  p.status AS last_payment_status
FROM member m
LEFT JOIN payment p 
  ON p.p_id = (
      SELECT p2.p_id
      FROM payment p2
      WHERE p2.m_id = m.m_id
      ORDER BY p2.p_id DESC
      LIMIT 1
  )
ORDER BY m.m_id DESC
";
$res = $mysqli->query($sql);

include __DIR__ . "/../partials/header.php";
?>
<div class="card">
  <h1>Manage Membership</h1>
  <p class="muted">
   

  <div class="row">
    <a class="btn" href="<?= h($base) ?>/admin/home.php">Admin Home</a>
  </div>

  <table>
    <thead>
      <tr>
        <th>Member ID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Contact</th>
        <th>Gender</th>
        <th>BMI</th>
        <th>Last Payment Date</th>
        <th>Last Payment Status</th>
        <th>Action</th>
      </tr>
    </thead>

    <tbody>
      <?php if ($res && $res->num_rows === 0): ?>
        <tr><td colspan="9" class="muted">No members found.</td></tr>
      <?php else: ?>
        <?php while($r = $res->fetch_assoc()): ?>
          <tr>
            <td><?= h($r["m_id"]) ?></td>
            <td><?= h($r["name"]) ?></td>
            <td><?= h($r["email"]) ?></td>
            <td><?= h($r["c_no"]) ?></td>
            <td><?= h($r["gender"]) ?></td>
            <td><?= h((string)$r["bmi"]) ?></td>
            <td><?= h($r["last_payment_date"] ?? "—") ?></td>
            <td><?= h($r["last_payment_status"] ?? "no record") ?></td>

            <td class="row">
              <?php
                $status = $r["last_payment_status"] ?? "";
                $isCancelled = ($status === "cancelled");
              ?>
              <?php if (!$isCancelled): ?>
                <a class="btn btn-danger"
                   href="<?= h($base) ?>/admin/cancel_membership.php?m_id=<?= h($r["m_id"]) ?>"
                   onclick="return confirm('Cancel membership for this member?')">
                   Cancel Membership
                </a>
              <?php else: ?>
                <span class="muted">Cancelled</span>
              <?php endif; ?>
            </td>
          </tr>
        <?php endwhile; ?>
      <?php endif; ?>
    </tbody>
  </table>
</div>
<?php include __DIR__ . "/../partials/footer.php"; ?>
