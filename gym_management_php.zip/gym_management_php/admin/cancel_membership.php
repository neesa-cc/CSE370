<?php
require_once __DIR__ . "/../config/auth.php";
require_login(["admin"]);

$base = get_base_url();

$m_id = (int)($_GET["m_id"] ?? 0);
if ($m_id <= 0) {
    die("Invalid member id");
}
$stmt = $mysqli->prepare("SELECT p_id FROM payment WHERE m_id=? ORDER BY p_id DESC LIMIT 1");
$stmt->bind_param("i", $m_id);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();

if ($row) {
    $p_id = (int)$row["p_id"];
    $stmt = $mysqli->prepare("UPDATE payment SET status='cancelled' WHERE p_id=? AND m_id=?");
    $stmt->bind_param("ii", $p_id, $m_id);
    $stmt->execute();
} else {
    $date = date("Y-m-d");
    $status = "cancelled";
    $stmt = $mysqli->prepare("INSERT INTO payment (date, status, m_id) VALUES (?, ?, ?)");
    $stmt->bind_param("ssi", $date, $status, $m_id);
    $stmt->execute();
}

redirect($base . "/admin/manage_membership.php");
