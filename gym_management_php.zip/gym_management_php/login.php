<?php
require_once __DIR__ . "/config/auth.php";

$title = "Login";
$error = "";
$base = get_base_url();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST["email"] ?? "");
    $pass  = $_POST["password"] ?? "";

    if ($email === "" || $pass === "") {
        $error = "Email and password are required.";
    } else {
        $roles = [
            "admin"  => ["table" => "admin",  "id" => "a_id"],
            "trainer"=> ["table" => "trainer","id" => "t_id"],
            "member" => ["table" => "member", "id" => "m_id"],
        ];

        foreach ($roles as $role => $info) {
            $sql = "SELECT {$info['id']} AS id, name, email, password FROM {$info['table']} WHERE email = ?";
            $stmt = $mysqli->prepare($sql);
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $res = $stmt->get_result();
            if ($row = $res->fetch_assoc()) {
                if ($pass === $row["password"]) {
                    $_SESSION["role"] = $role;
                    $_SESSION["user_id"] = (int)$row["id"];
                    $_SESSION["name"] = $row["name"];
                    redirect($base . "/index.php");
                }
            }
        }
        $error = "Invalid email or password.";
    }
}

include __DIR__ . "/partials/header.php";
?>
<div class="card">
  <h1>Login</h1>
  <p class="muted">Use email & password from <b>admin / trainer / member</b> tables.</p>

  <?php if ($error): ?>
    <div class="msg err"><?= h($error) ?></div>
  <?php endif; ?>

  <form method="post">
    <div class="grid">
      <div class="col-6">
        <label>Email</label>
        <input type="email" name="email" required>
      </div>
      <div class="col-6">
        <label>Password</label>
        <input type="password" name="password" required>
      </div>
      <div class="col-12 row">
        <button class="btn btn-primary" type="submit">Login</button>
        <a class="btn btn-ghost" href="<?= h($base) ?>/index.php">Home</a>
      </div>
    </div>
  </form>
</div>
<?php include __DIR__ . "/partials/footer.php"; ?>
