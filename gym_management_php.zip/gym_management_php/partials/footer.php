</main>
<footer class="footer">
  <div class="container muted">© Gym Management</div>
</footer>
</body>
</html>
