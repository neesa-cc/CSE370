<?php
// Show alerts only for Trainer + Member
if (!isset($_SESSION["role"])) return;
if (!in_array($_SESSION["role"], ["trainer", "member"], true)) return;

// Show only active alerts
$stmt = $mysqli->prepare("SELECT a_id, name FROM alert WHERE status='active' ORDER BY a_id DESC");
$stmt->execute();
$res = $stmt->get_result();

if ($res->num_rows === 0) return;
?>
<div class="card">
  <h2>System Alerts</h2>
  <ul style="margin:10px 0 0; padding-left:18px;">
    <?php while($a = $res->fetch_assoc()): ?>
      <li><?= h($a["name"]) ?></li>
    <?php endwhile; ?>
  </ul>
</div>

</header>
<main class="container">
