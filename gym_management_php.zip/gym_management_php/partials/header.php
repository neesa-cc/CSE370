<?php
require_once __DIR__ . "/../config/auth.php";
$base = get_base_url();
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title><?= h($title ?? "Gym System") ?></title>
  <link rel="stylesheet" href="<?= h($base) ?>/css/style.css">
</head>
<body>
<header class="topbar">
  <div class="container topbar-inner">
    <div class="brand">Gym Management</div>
    <nav class="nav">
      <?php if (isset($_SESSION["role"])): ?>
        <span class="badge"><?= h($_SESSION["role"]) ?></span>
        <span class="muted"><?= h(current_user_name()) ?></span>
        <a class="btn btn-ghost" href="<?= h($base) ?>/logout.php">Logout</a>
      <?php else: ?>
        <a class="btn btn-ghost" href="<?= h($base) ?>/login.php">Login</a>
      <?php endif; ?>
    </nav>
  </div>
</header>
<main class="container">
