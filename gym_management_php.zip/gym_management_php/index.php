<?php
require_once __DIR__ . "/config/auth.php";

if (!isset($_SESSION["role"])) {
    redirect(get_base_url() . "/login.php");
}

$base = get_base_url();
switch ($_SESSION["role"]) {
    case "admin":  redirect($base . "/admin/home.php");
    case "trainer": redirect($base . "/trainer/home.php");
    case "member": redirect($base . "/member/home.php");
    default: redirect($base . "/login.php");
}
