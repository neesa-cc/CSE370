<?php

$BASE_URL = "/gym_management_php";

