<?php
require_once __DIR__ . "/config.php";
require_once __DIR__ . "/db.php";
require_once __DIR__ . "/helpers.php";

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function require_login(array $roles = []): void {
    if (!isset($_SESSION["role"], $_SESSION["user_id"])) {
        redirect(get_base_url() . "/login.php");
    }
    if (!empty($roles) && !in_array($_SESSION["role"], $roles, true)) {
        http_response_code(403);
        die("403 Forbidden");
    }
}

function get_base_url(): string {
    global $BASE_URL;
    return $BASE_URL;
}

function current_role(): string {
    return $_SESSION["role"] ?? "";
}

function current_user_id(): int {
    return (int)($_SESSION["user_id"] ?? 0);
}

function current_user_name(): string {
    return $_SESSION["name"] ?? "";
}
