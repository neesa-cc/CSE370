<?php
require_once __DIR__ . "/../config/auth.php";
require_login(["trainer"]);
$title = "Add Specialization";
$base = get_base_url();
$t_id = current_user_id();
$msg = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $spec = trim($_POST["specialization"] ?? "");
    if ($spec !== "") {
        $stmt = $mysqli->prepare("INSERT INTO trainer_specialization (t_id, specialization) VALUES (?, ?)");
        $stmt->bind_param("is", $t_id, $spec);
        $stmt->execute();
        $msg = "Specialization added.";
    }
}

include __DIR__ . "/../partials/header.php";
?>
<div class="card">
  <h1>Add Specialization</h1>
  <?php if ($msg): ?><div class="msg"><?= h($msg) ?></div><?php endif; ?>
  <form method="post">
    <label>Specialization</label>
    <input name="specialization" required placeholder="e.g. Weight Loss, Bodybuilding">
    <div class="row" style="margin-top:12px">
      <button class="btn btn-primary" type="submit">Save</button>
      <a class="btn" href="<?= h($base) ?>/trainer/show_specialization.php">Back</a>
    </div>
  </form>
</div>
<?php include __DIR__ . "/../partials/footer.php"; ?>
