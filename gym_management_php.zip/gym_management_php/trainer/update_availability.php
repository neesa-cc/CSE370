<?php
require_once __DIR__ . "/../config/auth.php";
require_login(["trainer"]);
$title = "Update Availability";
$base = get_base_url();

$t_id = current_user_id();
$msg = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $availability = trim($_POST["availability"] ?? "offline");
    $stmt = $mysqli->prepare("UPDATE trainer SET availability=? WHERE t_id=?");
    $stmt->bind_param("si", $availability, $t_id);
    $stmt->execute();
    $msg = "Availability updated.";
}

$stmt = $mysqli->prepare("SELECT availability FROM trainer WHERE t_id=?");
$stmt->bind_param("i", $t_id);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();

include __DIR__ . "/../partials/header.php";
?>
<div class="card">
  <h1>Availability</h1>
  <?php if ($msg): ?><div class="msg"><?= h($msg) ?></div><?php endif; ?>
  <form method="post">
    <label>Availability</label>
    <select name="availability">
      <?php
        $opts = ["available","busy","offline"];
        foreach ($opts as $o) {
          $sel = ($row["availability"] ?? "") === $o ? "selected" : "";
          echo "<option value='".h($o)."' $sel>".h($o)."</option>";
        }
      ?>
    </select>
    <div class="row" style="margin-top:12px">
      <button class="btn btn-primary" type="submit">Save</button>
      <a class="btn" href="<?= h($base) ?>/trainer/home.php">Back</a>
    </div>
  </form>
</div>
<?php include __DIR__ . "/../partials/footer.php"; ?>
