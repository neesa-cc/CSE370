<?php
require_once __DIR__ . "/../config/auth.php";
require_login(["trainer"]);
$title = "Add Progress Note";
$base = get_base_url();
$t_id = current_user_id();

$m_id = (int)($_GET["m_id"] ?? ($_POST["m_id"] ?? 0));
$e_id = (int)($_GET["e_id"] ?? ($_POST["e_id"] ?? 0));

$msg = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $comment = trim($_POST["comment"] ?? "");

    // upsert (insert or update) based on composite PK
    $sql = "INSERT INTO complains (m_id, e_id, t_id, comment)
            VALUES (?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE comment=VALUES(comment)";
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param("iiis", $m_id, $e_id, $t_id, $comment);
    $stmt->execute();
    $msg = "Note saved.";
}

$stmt = $mysqli->prepare("SELECT comment FROM complains WHERE m_id=? AND e_id=? AND t_id=?");
$stmt->bind_param("iii", $m_id, $e_id, $t_id);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();

include __DIR__ . "/../partials/header.php";
?>
<div class="card">
  <h1>Progress Note</h1>
  <p class="muted">m_id: <?= h($m_id) ?> | e_id: <?= h($e_id) ?> | t_id: <?= h($t_id) ?></p>
  <?php if ($msg): ?><div class="msg"><?= h($msg) ?></div><?php endif; ?>
  <form method="post">
    <input type="hidden" name="m_id" value="<?= h($m_id) ?>">
    <input type="hidden" name="e_id" value="<?= h($e_id) ?>">
    <label>Comment</label>
    <textarea name="comment" required><?= h($row["comment"] ?? "") ?></textarea>
    <div class="row" style="margin-top:12px">
      <button class="btn btn-primary" type="submit">Save</button>
      <a class="btn" href="<?= h($base) ?>/trainer/show_requests.php">Back</a>
    </div>
  </form>
</div>
<?php include __DIR__ . "/../partials/footer.php"; ?>
