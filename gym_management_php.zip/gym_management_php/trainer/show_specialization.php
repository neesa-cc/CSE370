<?php
require_once __DIR__ . "/../config/auth.php";
require_login(["trainer"]);
$title = "My Specializations";
$base = get_base_url();
$t_id = current_user_id();

$stmt = $mysqli->prepare("SELECT specialization FROM trainer_specialization WHERE t_id=? ORDER BY specialization");
$stmt->bind_param("i", $t_id);
$stmt->execute();
$res = $stmt->get_result();

include __DIR__ . "/../partials/header.php";
?>
<div class="card">
  <h1>My Specializations</h1>
  <div class="row">
    <a class="btn btn-primary" href="<?= h($base) ?>/trainer/insert_specialization.php">+ Add</a>
    <a class="btn" href="<?= h($base) ?>/trainer/home.php">Trainer Home</a>
  </div>

  <table>
    <thead><tr><th>Specialization</th><th>Action</th></tr></thead>
    <tbody>
    <?php while($r = $res->fetch_assoc()): ?>
      <tr>
        <td><?= h($r["specialization"]) ?></td>
        <td>
          <a class="btn btn-danger"
             href="<?= h($base) ?>/trainer/delete_specialization.php?specialization=<?= urlencode($r["specialization"]) ?>"
             onclick="return confirm('Remove specialization?')">Delete</a>
        </td>
      </tr>
    <?php endwhile; ?>
    </tbody>
  </table>
</div>
<?php include __DIR__ . "/../partials/footer.php"; ?>
