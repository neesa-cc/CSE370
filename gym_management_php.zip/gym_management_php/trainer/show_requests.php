<?php
require_once __DIR__ . "/../config/auth.php";
require_login(["trainer"]);
$title = "Member Requests";
$base = get_base_url();
$t_id = current_user_id();

$sql = "
SELECT mr.m_id, mr.e_id, mr.req_status,
       m.name AS member_name,
       e.name AS equipment_name
FROM member_req mr
JOIN member m ON m.m_id = mr.m_id
LEFT JOIN equipment e ON e.e_id = mr.e_id
WHERE m.t_id = ?
ORDER BY mr.m_id DESC
";
$stmt = $mysqli->prepare($sql);
$stmt->bind_param("i", $t_id);
$stmt->execute();
$res = $stmt->get_result();

include __DIR__ . "/../partials/header.php";
?>
<div class="card">
  <h1>Requests</h1>
  <a class="btn" href="<?= h($base) ?>/trainer/home.php">Back</a>

  <table>
    <thead><tr><th>Member</th><th>Equipment</th><th>Status</th><th>Action</th></tr></thead>
    <tbody>
    <?php while($r = $res->fetch_assoc()): ?>
      <tr>
        <td><?= h($r["member_name"]) ?> (<?= h($r["m_id"]) ?>)</td>
        <td><?= h($r["equipment_name"] ?? "") ?> (<?= h($r["e_id"]) ?>)</td>
        <td><?= h($r["req_status"]) ?></td>
        <td class="row">
          <a class="btn" href="<?= h($base) ?>/trainer/modify_request.php?m_id=<?= h($r["m_id"]) ?>&e_id=<?= h($r["e_id"]) ?>">Update Status</a>
          <a class="btn btn-primary" href="<?= h($base) ?>/trainer/add_note.php?m_id=<?= h($r["m_id"]) ?>&e_id=<?= h($r["e_id"]) ?>">Add Note</a>
          <a class="btn btn-danger" href="<?= h($base) ?>/trainer/resolve_request.php?m_id=<?= h($r["m_id"]) ?>&e_id=<?= h($r["e_id"]) ?>">Resolve</a>
        </td>
      </tr>
    <?php endwhile; ?>
    </tbody>
  </table>
</div>
<?php include __DIR__ . "/../partials/footer.php"; ?>
