<?php
require_once __DIR__ . "/../config/auth.php";
require_login(["trainer"]);
$title = "Trainer Home";
$base = get_base_url();
include __DIR__ . "/../partials/header.php";
include __DIR__ . "/../partials/alerts_widget.php";

?>
<div class="card">
  <h1>Trainer Panel</h1>
  <div class="row">
    <a class="btn" href="<?= h($base) ?>/trainer/update_availability.php">Update Availability</a>
    <a class="btn btn-primary" href="<?= h($base) ?>/trainer/insert_specialization.php">Add Specialization</a>
    <a class="btn" href="<?= h($base) ?>/trainer/show_specialization.php">View Specializations</a>
    <a class="btn" href="<?= h($base) ?>/trainer/show_assigned_members.php">Assigned Members</a>
    <a class="btn" href="<?= h($base) ?>/trainer/show_requests.php">Member Requests</a>
    <a class="btn" href="<?= h($base) ?>/trainer/show_notes.php">Progress Notes</a>
  </div>
</div>
<?php include __DIR__ . "/../partials/footer.php"; ?>
