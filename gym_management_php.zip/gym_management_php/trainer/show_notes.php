<?php
require_once __DIR__ . "/../config/auth.php";
require_login(["trainer"]);
$title = "My Notes";
$base = get_base_url();
$t_id = current_user_id();

$sql = "
SELECT c.m_id, c.e_id, c.comment,
       m.name AS member_name,
       e.name AS equipment_name
FROM complains c
JOIN member m ON m.m_id=c.m_id
LEFT JOIN equipment e ON e.e_id=c.e_id
WHERE c.t_id=?
ORDER BY c.m_id DESC
";
$stmt = $mysqli->prepare($sql);
$stmt->bind_param("i", $t_id);
$stmt->execute();
$res = $stmt->get_result();

include __DIR__ . "/../partials/header.php";
?>
<div class="card">
  <h1>Progress Notes</h1>
  <a class="btn" href="<?= h($base) ?>/trainer/home.php">Back</a>
  <table>
    <thead><tr><th>Member</th><th>Equipment</th><th>Comment</th></tr></thead>
    <tbody>
    <?php while($r = $res->fetch_assoc()): ?>
      <tr>
        <td><?= h($r["member_name"]) ?> (<?= h($r["m_id"]) ?>)</td>
        <td><?= h($r["equipment_name"] ?? "") ?> (<?= h($r["e_id"]) ?>)</td>
        <td><?= h($r["comment"]) ?></td>
      </tr>
    <?php endwhile; ?>
    </tbody>
  </table>
</div>
<?php include __DIR__ . "/../partials/footer.php"; ?>
