<?php
require_once __DIR__ . "/../config/auth.php";
require_login(["trainer"]);
$base = get_base_url();
$t_id = current_user_id();

$spec = $_GET["specialization"] ?? "";
$stmt = $mysqli->prepare("DELETE FROM trainer_specialization WHERE t_id=? AND specialization=?");
$stmt->bind_param("is", $t_id, $spec);
$stmt->execute();

redirect($base . "/trainer/show_specialization.php");
