<?php
require_once __DIR__ . "/../config/auth.php";
require_login(["trainer"]);
$title = "Modify Request";
$base = get_base_url();
$t_id = current_user_id();

$m_id = (int)($_GET["m_id"] ?? 0);
$e_id = (int)($_GET["e_id"] ?? 0);

$sql = "SELECT mr.req_status, m.t_id FROM member_req mr JOIN member m ON m.m_id=mr.m_id WHERE mr.m_id=? AND mr.e_id=?";
$stmt = $mysqli->prepare($sql);
$stmt->bind_param("ii", $m_id, $e_id);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();
if (!$row || (int)$row["t_id"] !== $t_id) die("Not allowed.");

include __DIR__ . "/../partials/header.php";
?>
<div class="card">
  <h1>Update Request</h1>
  <p class="muted">Member ID: <?= h($m_id) ?> | Equipment ID: <?= h($e_id) ?></p>

  <form method="post" action="<?= h($base) ?>/trainer/update_request.php">
    <input type="hidden" name="m_id" value="<?= h($m_id) ?>">
    <input type="hidden" name="e_id" value="<?= h($e_id) ?>">

    <label>Status</label>
    <select name="req_status">
      <?php
        $opts = ["pending","approved","rejected","cancelled","resolved"];
        foreach ($opts as $o) {
          $sel = ($row["req_status"] ?? "") === $o ? "selected" : "";
          echo "<option value='".h($o)."' $sel>".h($o)."</option>";
        }
      ?>
    </select>

    <div class="row" style="margin-top:12px">
      <button class="btn btn-primary" type="submit">Save</button>
      <a class="btn" href="<?= h($base) ?>/trainer/show_requests.php">Back</a>
    </div>
  </form>
</div>
<?php include __DIR__ . "/../partials/footer.php"; ?>
