<?php
require_once __DIR__ . "/../config/auth.php";
require_login(["trainer"]);
$base = get_base_url();
$t_id = current_user_id();

$m_id = (int)($_POST["m_id"] ?? 0);
$e_id = (int)($_POST["e_id"] ?? 0);
$status = trim($_POST["req_status"] ?? "pending");

// ensure member belongs to this trainer
$stmt = $mysqli->prepare("SELECT t_id FROM member WHERE m_id=?");
$stmt->bind_param("i", $m_id);
$stmt->execute();
$owner = $stmt->get_result()->fetch_assoc();
if (!$owner || (int)$owner["t_id"] !== $t_id) die("Not allowed.");

$stmt = $mysqli->prepare("UPDATE member_req SET req_status=? WHERE m_id=? AND e_id=?");
$stmt->bind_param("sii", $status, $m_id, $e_id);
$stmt->execute();

redirect($base . "/trainer/show_requests.php");
