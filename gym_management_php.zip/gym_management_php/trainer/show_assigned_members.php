<?php
require_once __DIR__ . "/../config/auth.php";
require_login(["trainer"]);
$title = "Assigned Members";
$base = get_base_url();
$t_id = current_user_id();

$stmt = $mysqli->prepare("SELECT m_id, name, email, c_no, gender, bmi FROM member WHERE t_id=? ORDER BY m_id DESC");
$stmt->bind_param("i", $t_id);
$stmt->execute();
$res = $stmt->get_result();

include __DIR__ . "/../partials/header.php";
?>
<div class="card">
  <h1>Assigned Members</h1>
  <a class="btn" href="<?= h($base) ?>/trainer/home.php">Back</a>
  <table>
    <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Contact</th><th>Gender</th><th>BMI</th></tr></thead>
    <tbody>
    <?php while($r = $res->fetch_assoc()): ?>
      <tr>
        <td><?= h($r["m_id"]) ?></td>
        <td><?= h($r["name"]) ?></td>
        <td><?= h($r["email"]) ?></td>
        <td><?= h($r["c_no"]) ?></td>
        <td><?= h($r["gender"]) ?></td>
        <td><?= h((string)$r["bmi"]) ?></td>
      </tr>
    <?php endwhile; ?>
    </tbody>
  </table>
</div>
<?php include __DIR__ . "/../partials/footer.php"; ?>
