<?php
require_once __DIR__ . "/config/auth.php";
session_destroy();
redirect(get_base_url() . "/login.php");
